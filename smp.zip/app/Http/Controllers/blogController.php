<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\blogModel;

class blogController extends Controller
{
    public function index()
    {
        $lastt = blogModel::orderBy('tgl', 'DESC')->limit(3)->get();
        $blogs = blogModel::orderBy('tgl', 'DESC')->paginate(6);
        return view('blog')->with('blogs', $blogs)->with('lastt', $lastt);
    }
}
