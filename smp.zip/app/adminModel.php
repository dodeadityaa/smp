<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adminModel extends Model
{
    //
}
