<!-- Main Footer -->
<footer class="main-footer">
    <strong>Copyright &copy; 2022 DJB School.</strong>
</footer>
<!-- Main Footer -->