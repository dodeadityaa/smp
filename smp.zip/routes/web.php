<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

//admin
Route::group(['middleware' => ['auth', 'AccessAdmin:admin']], function () {

    Route::get('/dashboard', 'admin\dashboardController@index');
    Route::resource('admins-view', 'admin\adminController');
    Route::resource('guru-view', 'admin\dataguruController');
    Route::resource('blog-view', 'admin\blogController');
    Route::resource('pengumuman-view', 'admin\pengumumanController');
});
//admin

//login admin dan guru
Route::post('/login/masuk', 'admin\loginController@postlogin');
//register guru admin
Auth::routes();
//register guru admin

//verifikasi email guru
// Auth::routes(['verify' => true]);
Route::get('/notif', 'notifController@index');

Route::resource('index', 'indexController');
Route::get('/pengumuman', 'pengumumanController@index');
Route::get('/blog', 'blogController@index');
Route::get('/profil', 'profilController@index');
Route::get('/', 'indexController@index');
Route::get('/guru', 'guruController@index');
Route::get('/guru/2', 'guruController@guru');
Route::get('/guru/3', 'guruController@guru3');
Route::get('/kontak', 'kontakController@index');
