<?php if($paginator->lastPage() > 1): ?>
<?php if($paginator->currentPage() == 1): ?>
<ul class="pagination">
    <li class="page-item"><a class="page-link" href="#">kembali</a></li>
    <li class="page-item"><a class="page-link" href="<?php echo e($paginator->url($paginator->currentPage() + 1)); ?>">next</a></li>
    <?php elseif($paginator->currentPage() == $paginator->lastPage()): ?>
    <li class="page-item"><a class="page-link" href="<?php echo e($paginator->url($paginator->currentPage() - 1)); ?>">kembali</a></li>
    <li class="page-item"><a class="page-link" href="#">next</a></li>
    <?php else: ?>
    <li class="page-item"><a class="page-link" href="<?php echo e($paginator->url($paginator->currentPage() - 1)); ?>">kembali</a></li>
    <li class="page-item"><a class="page-link" href="<?php echo e($paginator->url($paginator->currentPage() + 1)); ?>">next</a></li>
</ul>
<?php endif; ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\smp-dwijendra\resources\views/bagian/pagination.blade.php ENDPATH**/ ?>