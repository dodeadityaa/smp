<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>SMP DWIJENDRA BUALU</title>

    <!-- Favicon -->
    <?php echo $__env->make('bagian.icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Stylesheet -->
    <?php echo $__env->make('bagian.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>

    <!-- ##### Loading ##### -->
    <?php echo $__env->make('bagian.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ##### Header Area Start ##### -->
    <?php echo $__env->make('bagian.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Blog Area Start ##### -->
    <div class="blog-area section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-8">
                    <div class="faith-blog-posts">
                        <div class="row">

                            <!-- Single Blog Area -->
                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 col-lg-6">
                                <div class="single-blog-area mb-100">
                                    <div class="blog-thumbnail">
                                        <img src="<?php echo e(URL::to('/')); ?>/fotoblog/<?php echo e($item->foto_blog); ?>" class="img-thumbnail" width="75" />
                                        <div class="post-date">
                                            <a href="#"><?php echo e($item->tgl->toFormattedDateString()); ?></a>
                                        </div>
                                    </div>
                                    <div class="blog-content">
                                        <a href="#" class="blog-title"><?php echo e($item->judul); ?></a>
                                        <p><?php echo substr($item->blog, 0, 100); ?>...</p>
                                        <a href="#" class="readmore-btn">Read More</a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- Pagination Area -->
                    <div class="pagination-area">
                        <nav aria-label="Page navigation">
                            <?php echo $__env->make('bagian.pagination', ['paginator' => $blogs->appends(Request::except('page'))], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </nav>
                    </div>
                </div>

                <div class="col-12 col-lg-4">
                    <div class="faith-blog-sidebar-area">

                        <!-- Widget -->
                        <div class="blog-widget-area">
                            <h5>Categories</h5>
                            <ul>
                                <li><a href="#">Saint</a></li>
                                <li><a href="#">Penelitian</a></li>
                                <li><a href="#">Prestasi</a></li>
                                <li><a href="#">Olahraga</a></li>
                                <li><a href="#">Warga Sekolah</a></li>
                                <li><a href="#">Politik</a></li>
                                <li><a href="#">Pendidikan</a></li>
                            </ul>
                        </div>

                        <!-- Widget -->
                        <div class="blog-widget-area">
                            <h5>Latest Posts</h5>

                            <!-- Single Latest Blog Post -->
                            <?php $__currentLoopData = $lastt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it => $itemm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-latest-blog-post d-flex mb-30">
                                <div class="latest-blog-post-thumb">
                                    <img src="<?php echo e(URL::to('/')); ?>/fotoblog/<?php echo e($itemm->foto_blog); ?>" class="img-thumbnail" />
                                </div>
                                <div class="latest-blog-post-content">
                                    <a href="#" class="post-title"><?php echo e($itemm->judul); ?></a>
                                    <a href="#" class="post-date"><?php echo e($itemm->tgl->toFormattedDateString()); ?></a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Blog Area End ##### -->


    <!-- ##### Footer Area Start ##### -->
    <?php echo $__env->make('bagian.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="/indexcss/js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="/indexcss/js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="/indexcss/js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="/indexcss/js/plugins/plugins.js"></script>
    <script src="/indexcss/js/plugins/audioplayer.js"></script>
    <!-- Active js -->
    <script src="/indexcss/js/active.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\smp-dwijendra\resources\views/blog.blade.php ENDPATH**/ ?>