<!-- Main Footer -->
<footer class="main-footer">
    <strong>Copyright &copy; 2022 DJB School.</strong>
</footer>
<!-- Main Footer --><?php /**PATH C:\xampp\htdocs\smp-dwijendra\resources\views/bagian/footeradmin.blade.php ENDPATH**/ ?>