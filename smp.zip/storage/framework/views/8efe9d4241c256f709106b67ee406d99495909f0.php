<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>SMP DWIJENDRA BUALU</title>

    <!-- Favicon -->
    <?php echo $__env->make('bagian.icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Stylesheet -->
    <?php echo $__env->make('bagian.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>

    <!-- ##### Loading ##### -->
    <?php echo $__env->make('bagian.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ##### Header Area Start ##### -->
    <?php echo $__env->make('bagian.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Slide Bar Start ##### -->
    <section class="hero-area">
        <div class="hero-slides owl-carousel">
            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img bg-overlay" style="background-image: url(indexcss/img/lainnya/banner1.jpeg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-center justify-content-end">
                        <div class="col-12 col-lg-7">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img bg-overlay" style="background-image: url(indexcss/img/lainnya/banner2.jpeg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-center justify-content-end">
                        <div class="col-12 col-lg-7">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img bg-overlay" style="background-image: url(indexcss/img/lainnya/banner3.jpeg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12 col-lg-7">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### Slide Bar End ##### -->
    <!-- ##### seputar dwijendra Start ##### -->
    <div class="faith-blog-area section-padding-100-0">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading text-center mx-auto">
                        <h3>Seputar DJB School</h3>
                        <p>berikut adalah kegiatan seputar DJB School</p>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Single Blog Area -->
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-lg-4">
                    <div class="single-blog-area mb-100">
                        <div class="blog-thumbnail">
                            <img src="<?php echo e(URL::to('/')); ?>/fotoblog/<?php echo e($item->foto_blog); ?>" class="img-thumbnail" width="75" />
                            <div class="post-date">
                                <a href="#"><?php echo e($item->tgl->toFormattedDateString()); ?></a>
                            </div>
                        </div>
                        <div class="blog-content">
                            <a href="#" class="blog-title"><?php echo e($item->judul); ?></a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <center>
        <a href="/blog" class="btn btn-warning mb-100">Lihat Berita Lainnya</a>
    </center>
    <!-- ##### seputar dwijendra Start ##### -->
    <!-- ##### pengumuman Area Start ##### -->
    <section class="donate-our-charities section-padding-100 bg-img bg-overlay" style="background-color: #0415b4;">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading white text-center mx-auto">
                        <h4>Pengumuman DJB School</h4>
                    </div>
                </div>
            </div>
            <?php $__currentLoopData = $pengumumans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col-12 col-lg-1">
                    <div class="fa fa-bullhorn fa-4x" style="color:white">
                    </div>
                </div>

                <div class="col-12 col-lg-11">
                    <h4 style="color: white"><?php echo e($item->judul_pengumuman); ?></h4>
                    <h5 style="color: white"><?php echo e($item->tgl->toFormattedDateString()); ?></h5>
                    <p style="color: white"><?php echo $item->detail_pengumuman; ?>

                    </p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
    </section>
    <section class="section-padding-100 bg-img bg-overlay" style="background-image: url(indexcss/img/lainnya/siswa.jpeg);">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="faith-cool-facts-area">
                        <div class="row">

                            <!-- Single Cool Fact -->
                            <div class="col-12 col-sm-6 col-md-4">
                                <div class="single-cool-fact text-center mb-100">
                                    <h3><span class="counter">11</span></h3>
                                    <h6>Guru</h6>
                                </div>
                            </div>

                            <!-- Single Cool Fact -->
                            <div class="col-12 col-sm-6 col-md-4">
                                <div class="single-cool-fact text-center mb-100">
                                    <h3><span class="counter">456</span></h3>
                                    <h6>siswa</h6>
                                </div>
                            </div>

                            <!-- Single Cool Fact -->
                            <div class="col-12 col-sm-6 col-md-4">
                                <div class="single-cool-fact text-center mb-100">
                                    <h3><span class="counter">7</span></h3>
                                    <div class="line"></div>
                                    <h6>Pegawai</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
            </div>
        </div>
        </div>
    </section>

    <!-- ##### pengumuman Area Start ##### -->


    <!-- ##### Footer Area Start ##### -->
    <?php echo $__env->make('bagian.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="/indexcss/js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="/indexcss/js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="/indexcss/js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="/indexcss/js/plugins/plugins.js"></script>
    <script src="/indexcss/js/plugins/audioplayer.js"></script>
    <!-- Active js -->
    <script src="/indexcss/js/active.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\smp-dwijendra\resources\views/index.blade.php ENDPATH**/ ?>