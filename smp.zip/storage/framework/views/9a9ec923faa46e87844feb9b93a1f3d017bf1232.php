    <!-- Favicon -->
    <link rel="icon" href="/indexcss/img/bg-img/bgbualu.png"><?php /**PATH C:\xampp\htdocs\smp-dwijendra\resources\views/bagian/icon.blade.php ENDPATH**/ ?>