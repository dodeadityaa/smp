<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>SMP DWIJENDRA BUALU</title>

    <!-- Favicon -->
    <?php echo $__env->make('bagian.icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Stylesheet -->
    <?php echo $__env->make('bagian.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>

    <!-- ##### Loading ##### -->
    <?php echo $__env->make('bagian.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ##### Header Area Start ##### -->
    <?php echo $__env->make('bagian.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ##### Header Area End ##### -->
    <!-- ##### pengumuman Area Start ##### -->
    <section class="ministries-area section-padding-100-0">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading text-center mx-auto">
                        <img src="indexcss/img/core-img/cross.png" alt="">
                        <h3>Pengumuman DJB School</h3>
                    </div>
                </div>
            </div>
            <?php $__currentLoopData = $pengumumans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="single-sermons style-3">
                <div class="sermons-content d-flex align-items-center">
                    <!-- Sermons Thumbnail -->
                    <div class="event-date">
                        <h4><?php echo e($item->tgl->isoFormat('D')); ?></h4> <span><?php echo e($item->tgl->isoFormat('MMM YYYY')); ?></span>
                    </div>
                    <!-- Sermons Content -->
                    <div class="sermons-text">
                        <a href="#">
                            <h6><?php echo e($item->judul_pengumuman); ?></h6>
                        </a>
                        <p class="text"><?php echo $item->detail_pengumuman; ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <!-- Pagination Area -->
    <div class="pagination-area">
        <nav aria-label="Page navigation">
            <?php echo $__env->make('bagian.pagination', ['paginator' => $pengumumans->appends(Request::except('page'))], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
    </div>
    <!-- ##### pengumuman Area End ##### -->


    <!-- ##### Footer Area Start ##### -->
    <?php echo $__env->make('bagian.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="/indexcss/js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="/indexcss/js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="/indexcss/js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="/indexcss/js/plugins/plugins.js"></script>
    <script src="/indexcss/js/plugins/audioplayer.js"></script>
    <!-- Active js -->
    <script src="/indexcss/js/active.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\smp-dwijendra\resources\views/pengumuman.blade.php ENDPATH**/ ?>