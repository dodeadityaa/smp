    <!-- Stylesheet -->
    <link rel="stylesheet" href="/indexcss/css/style.css">
    <link rel="stylesheet" href="/indexcss/css/tanggal.css"><?php /**PATH C:\xampp\htdocs\smp-dwijendra\resources\views/bagian/css.blade.php ENDPATH**/ ?>